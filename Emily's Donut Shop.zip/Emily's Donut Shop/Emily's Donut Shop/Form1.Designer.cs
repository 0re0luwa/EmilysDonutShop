﻿namespace Emily_s_Donut_Shop
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpDonutChoices = new System.Windows.Forms.GroupBox();
            this.lblChocAlmond = new System.Windows.Forms.Label();
            this.lblBendera = new System.Windows.Forms.Label();
            this.lblChocFrost = new System.Windows.Forms.Label();
            this.lblBlackForest = new System.Windows.Forms.Label();
            this.lblSugarRaises = new System.Windows.Forms.Label();
            this.lblGlazed = new System.Windows.Forms.Label();
            this.rdoChocAlmond = new System.Windows.Forms.RadioButton();
            this.rdoBendera = new System.Windows.Forms.RadioButton();
            this.rdoChocFrost = new System.Windows.Forms.RadioButton();
            this.rdoBlackForest = new System.Windows.Forms.RadioButton();
            this.rdoSugarRaised = new System.Windows.Forms.RadioButton();
            this.rdoGlazed = new System.Windows.Forms.RadioButton();
            this.chkAddCoffee = new System.Windows.Forms.CheckBox();
            this.listBox = new System.Windows.Forms.ListView();
            this.colItem = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colQTY = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colPrice = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.numQTY = new System.Windows.Forms.NumericUpDown();
            this.grpTotal = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtChangeDue = new System.Windows.Forms.TextBox();
            this.txtTendered = new System.Windows.Forms.TextBox();
            this.txtTotalDue = new System.Windows.Forms.TextBox();
            this.numTax = new System.Windows.Forms.NumericUpDown();
            this.txtSubtotal = new System.Windows.Forms.TextBox();
            this.grpCoffeeChoices = new System.Windows.Forms.GroupBox();
            this.rdoCappuccino = new System.Windows.Forms.RadioButton();
            this.rdoEspresso = new System.Windows.Forms.RadioButton();
            this.rdoRegular = new System.Windows.Forms.RadioButton();
            this.grpDonutChoices.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numQTY)).BeginInit();
            this.grpTotal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numTax)).BeginInit();
            this.grpCoffeeChoices.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpDonutChoices
            // 
            this.grpDonutChoices.Controls.Add(this.lblChocAlmond);
            this.grpDonutChoices.Controls.Add(this.lblBendera);
            this.grpDonutChoices.Controls.Add(this.lblChocFrost);
            this.grpDonutChoices.Controls.Add(this.lblBlackForest);
            this.grpDonutChoices.Controls.Add(this.lblSugarRaises);
            this.grpDonutChoices.Controls.Add(this.lblGlazed);
            this.grpDonutChoices.Controls.Add(this.rdoChocAlmond);
            this.grpDonutChoices.Controls.Add(this.rdoBendera);
            this.grpDonutChoices.Controls.Add(this.rdoChocFrost);
            this.grpDonutChoices.Controls.Add(this.rdoBlackForest);
            this.grpDonutChoices.Controls.Add(this.rdoSugarRaised);
            this.grpDonutChoices.Controls.Add(this.rdoGlazed);
            this.grpDonutChoices.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpDonutChoices.Location = new System.Drawing.Point(23, 24);
            this.grpDonutChoices.Name = "grpDonutChoices";
            this.grpDonutChoices.Size = new System.Drawing.Size(357, 362);
            this.grpDonutChoices.TabIndex = 0;
            this.grpDonutChoices.TabStop = false;
            this.grpDonutChoices.Text = "Donut Choices";
            // 
            // lblChocAlmond
            // 
            this.lblChocAlmond.AutoSize = true;
            this.lblChocAlmond.Location = new System.Drawing.Point(208, 324);
            this.lblChocAlmond.Name = "lblChocAlmond";
            this.lblChocAlmond.Size = new System.Drawing.Size(148, 16);
            this.lblChocAlmond.TabIndex = 11;
            this.lblChocAlmond.Text = "Choc Almond ($1.50)";
            // 
            // lblBendera
            // 
            this.lblBendera.AutoSize = true;
            this.lblBendera.Location = new System.Drawing.Point(38, 324);
            this.lblBendera.Name = "lblBendera";
            this.lblBendera.Size = new System.Drawing.Size(116, 16);
            this.lblBendera.TabIndex = 10;
            this.lblBendera.Text = "Bendera ($2.55)";
            // 
            // lblChocFrost
            // 
            this.lblChocFrost.AutoSize = true;
            this.lblChocFrost.Location = new System.Drawing.Point(208, 219);
            this.lblChocFrost.Name = "lblChocFrost";
            this.lblChocFrost.Size = new System.Drawing.Size(131, 16);
            this.lblChocFrost.TabIndex = 9;
            this.lblChocFrost.Text = "Choc Frost ($1.90)";
            // 
            // lblBlackForest
            // 
            this.lblBlackForest.AutoSize = true;
            this.lblBlackForest.Location = new System.Drawing.Point(38, 219);
            this.lblBlackForest.Name = "lblBlackForest";
            this.lblBlackForest.Size = new System.Drawing.Size(144, 16);
            this.lblBlackForest.TabIndex = 8;
            this.lblBlackForest.Text = "Black Forest ($1.75)";
            // 
            // lblSugarRaises
            // 
            this.lblSugarRaises.AutoSize = true;
            this.lblSugarRaises.Location = new System.Drawing.Point(194, 104);
            this.lblSugarRaises.Name = "lblSugarRaises";
            this.lblSugarRaises.Size = new System.Drawing.Size(151, 16);
            this.lblSugarRaises.TabIndex = 7;
            this.lblSugarRaises.Text = "Sugar Raises ($1.45)";
            // 
            // lblGlazed
            // 
            this.lblGlazed.AutoSize = true;
            this.lblGlazed.Location = new System.Drawing.Point(43, 104);
            this.lblGlazed.Name = "lblGlazed";
            this.lblGlazed.Size = new System.Drawing.Size(106, 16);
            this.lblGlazed.TabIndex = 6;
            this.lblGlazed.Text = "Glazed ($1.35)";
            // 
            // rdoChocAlmond
            // 
            this.rdoChocAlmond.AutoSize = true;
            this.rdoChocAlmond.Image = global::Emily_s_Donut_Shop.Properties.Resources.choc_almond;
            this.rdoChocAlmond.Location = new System.Drawing.Point(193, 255);
            this.rdoChocAlmond.Name = "rdoChocAlmond";
            this.rdoChocAlmond.Size = new System.Drawing.Size(96, 60);
            this.rdoChocAlmond.TabIndex = 5;
            this.rdoChocAlmond.TabStop = true;
            this.rdoChocAlmond.UseVisualStyleBackColor = true;
            // 
            // rdoBendera
            // 
            this.rdoBendera.AutoSize = true;
            this.rdoBendera.Image = global::Emily_s_Donut_Shop.Properties.Resources.bendera_small;
            this.rdoBendera.Location = new System.Drawing.Point(26, 255);
            this.rdoBendera.Name = "rdoBendera";
            this.rdoBendera.Size = new System.Drawing.Size(94, 66);
            this.rdoBendera.TabIndex = 4;
            this.rdoBendera.TabStop = true;
            this.rdoBendera.UseVisualStyleBackColor = true;
            // 
            // rdoChocFrost
            // 
            this.rdoChocFrost.AutoSize = true;
            this.rdoChocFrost.Image = global::Emily_s_Donut_Shop.Properties.Resources.choc_frost_s;
            this.rdoChocFrost.Location = new System.Drawing.Point(193, 149);
            this.rdoChocFrost.Name = "rdoChocFrost";
            this.rdoChocFrost.Size = new System.Drawing.Size(95, 64);
            this.rdoChocFrost.TabIndex = 3;
            this.rdoChocFrost.TabStop = true;
            this.rdoChocFrost.UseVisualStyleBackColor = true;
            // 
            // rdoBlackForest
            // 
            this.rdoBlackForest.AutoSize = true;
            this.rdoBlackForest.Image = global::Emily_s_Donut_Shop.Properties.Resources.black_forest_s;
            this.rdoBlackForest.Location = new System.Drawing.Point(26, 149);
            this.rdoBlackForest.Name = "rdoBlackForest";
            this.rdoBlackForest.Size = new System.Drawing.Size(93, 67);
            this.rdoBlackForest.TabIndex = 2;
            this.rdoBlackForest.TabStop = true;
            this.rdoBlackForest.UseVisualStyleBackColor = true;
            // 
            // rdoSugarRaised
            // 
            this.rdoSugarRaised.AutoSize = true;
            this.rdoSugarRaised.Image = global::Emily_s_Donut_Shop.Properties.Resources.suger_raised_s;
            this.rdoSugarRaised.Location = new System.Drawing.Point(193, 34);
            this.rdoSugarRaised.Name = "rdoSugarRaised";
            this.rdoSugarRaised.Size = new System.Drawing.Size(94, 67);
            this.rdoSugarRaised.TabIndex = 1;
            this.rdoSugarRaised.TabStop = true;
            this.rdoSugarRaised.UseVisualStyleBackColor = true;
            // 
            // rdoGlazed
            // 
            this.rdoGlazed.AutoSize = true;
            this.rdoGlazed.Image = global::Emily_s_Donut_Shop.Properties.Resources.glazed_s;
            this.rdoGlazed.Location = new System.Drawing.Point(26, 34);
            this.rdoGlazed.Name = "rdoGlazed";
            this.rdoGlazed.Size = new System.Drawing.Size(93, 67);
            this.rdoGlazed.TabIndex = 0;
            this.rdoGlazed.TabStop = true;
            this.rdoGlazed.UseVisualStyleBackColor = true;
            // 
            // chkAddCoffee
            // 
            this.chkAddCoffee.AutoSize = true;
            this.chkAddCoffee.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkAddCoffee.Location = new System.Drawing.Point(23, 419);
            this.chkAddCoffee.Name = "chkAddCoffee";
            this.chkAddCoffee.Size = new System.Drawing.Size(111, 20);
            this.chkAddCoffee.TabIndex = 6;
            this.chkAddCoffee.Text = "Add Coffee?";
            this.chkAddCoffee.UseVisualStyleBackColor = true;
            this.chkAddCoffee.CheckedChanged += new System.EventHandler(this.chkAddCoffee_CheckedChanged);
            // 
            // listBox
            // 
            this.listBox.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colItem,
            this.colQTY,
            this.colPrice,
            this.columnHeader1});
            this.listBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox.HideSelection = false;
            this.listBox.Location = new System.Drawing.Point(395, 61);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(298, 284);
            this.listBox.TabIndex = 7;
            this.listBox.UseCompatibleStateImageBehavior = false;
            this.listBox.View = System.Windows.Forms.View.Details;
            // 
            // colItem
            // 
            this.colItem.Text = "Item";
            this.colItem.Width = 160;
            // 
            // colQTY
            // 
            this.colQTY.Text = "QTY";
            this.colQTY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // colPrice
            // 
            this.colPrice.Text = "Price";
            this.colPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "";
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(507, 24);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 8;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemove.Location = new System.Drawing.Point(600, 24);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(75, 23);
            this.btnRemove.TabIndex = 9;
            this.btnRemove.Text = "Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // numQTY
            // 
            this.numQTY.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numQTY.Location = new System.Drawing.Point(395, 27);
            this.numQTY.Name = "numQTY";
            this.numQTY.Size = new System.Drawing.Size(79, 22);
            this.numQTY.TabIndex = 10;
            this.numQTY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numQTY.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // grpTotal
            // 
            this.grpTotal.Controls.Add(this.label5);
            this.grpTotal.Controls.Add(this.label4);
            this.grpTotal.Controls.Add(this.label3);
            this.grpTotal.Controls.Add(this.label2);
            this.grpTotal.Controls.Add(this.label1);
            this.grpTotal.Controls.Add(this.txtChangeDue);
            this.grpTotal.Controls.Add(this.txtTendered);
            this.grpTotal.Controls.Add(this.txtTotalDue);
            this.grpTotal.Controls.Add(this.numTax);
            this.grpTotal.Controls.Add(this.txtSubtotal);
            this.grpTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpTotal.Location = new System.Drawing.Point(395, 372);
            this.grpTotal.Name = "grpTotal";
            this.grpTotal.Size = new System.Drawing.Size(280, 179);
            this.grpTotal.TabIndex = 11;
            this.grpTotal.TabStop = false;
            this.grpTotal.Text = "Total";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(46, 149);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(96, 16);
            this.label5.TabIndex = 9;
            this.label5.Text = "Change Due:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(60, 116);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "Tendered:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(59, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "Total Due:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(75, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "Tax(%):";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(68, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 16);
            this.label1.TabIndex = 5;
            this.label1.Text = "Subtotal:";
            // 
            // txtChangeDue
            // 
            this.txtChangeDue.Location = new System.Drawing.Point(144, 147);
            this.txtChangeDue.Name = "txtChangeDue";
            this.txtChangeDue.ReadOnly = true;
            this.txtChangeDue.Size = new System.Drawing.Size(120, 22);
            this.txtChangeDue.TabIndex = 4;
            this.txtChangeDue.Text = "$0.00";
            this.txtChangeDue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTendered
            // 
            this.txtTendered.Location = new System.Drawing.Point(144, 114);
            this.txtTendered.Name = "txtTendered";
            this.txtTendered.Size = new System.Drawing.Size(120, 22);
            this.txtTendered.TabIndex = 3;
            this.txtTendered.Text = "$0.00";
            this.txtTendered.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTendered.TextChanged += new System.EventHandler(this.txtTendered_TextChanged);
            // 
            // txtTotalDue
            // 
            this.txtTotalDue.Location = new System.Drawing.Point(144, 77);
            this.txtTotalDue.Name = "txtTotalDue";
            this.txtTotalDue.ReadOnly = true;
            this.txtTotalDue.Size = new System.Drawing.Size(120, 22);
            this.txtTotalDue.TabIndex = 2;
            this.txtTotalDue.Text = "$0.00";
            this.txtTotalDue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numTax
            // 
            this.numTax.DecimalPlaces = 2;
            this.numTax.Increment = new decimal(new int[] {
            25,
            0,
            0,
            131072});
            this.numTax.Location = new System.Drawing.Point(144, 49);
            this.numTax.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numTax.Minimum = new decimal(new int[] {
            725,
            0,
            0,
            131072});
            this.numTax.Name = "numTax";
            this.numTax.Size = new System.Drawing.Size(120, 22);
            this.numTax.TabIndex = 1;
            this.numTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numTax.Value = new decimal(new int[] {
            725,
            0,
            0,
            131072});
            this.numTax.ValueChanged += new System.EventHandler(this.numTax_ValueChanged);
            // 
            // txtSubtotal
            // 
            this.txtSubtotal.Location = new System.Drawing.Point(144, 20);
            this.txtSubtotal.Name = "txtSubtotal";
            this.txtSubtotal.Size = new System.Drawing.Size(120, 22);
            this.txtSubtotal.TabIndex = 0;
            this.txtSubtotal.Text = "$0.00";
            this.txtSubtotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // grpCoffeeChoices
            // 
            this.grpCoffeeChoices.Controls.Add(this.rdoCappuccino);
            this.grpCoffeeChoices.Controls.Add(this.rdoEspresso);
            this.grpCoffeeChoices.Controls.Add(this.rdoRegular);
            this.grpCoffeeChoices.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpCoffeeChoices.Location = new System.Drawing.Point(175, 399);
            this.grpCoffeeChoices.Name = "grpCoffeeChoices";
            this.grpCoffeeChoices.Size = new System.Drawing.Size(193, 142);
            this.grpCoffeeChoices.TabIndex = 10;
            this.grpCoffeeChoices.TabStop = false;
            this.grpCoffeeChoices.Text = "Coffee Choices";
            // 
            // rdoCappuccino
            // 
            this.rdoCappuccino.AutoSize = true;
            this.rdoCappuccino.Location = new System.Drawing.Point(11, 99);
            this.rdoCappuccino.Name = "rdoCappuccino";
            this.rdoCappuccino.Size = new System.Drawing.Size(157, 20);
            this.rdoCappuccino.TabIndex = 2;
            this.rdoCappuccino.TabStop = true;
            this.rdoCappuccino.Text = "Cappuccino ($3.49)";
            this.rdoCappuccino.UseVisualStyleBackColor = true;
            // 
            // rdoEspresso
            // 
            this.rdoEspresso.AutoSize = true;
            this.rdoEspresso.Location = new System.Drawing.Point(11, 62);
            this.rdoEspresso.Name = "rdoEspresso";
            this.rdoEspresso.Size = new System.Drawing.Size(141, 20);
            this.rdoEspresso.TabIndex = 1;
            this.rdoEspresso.TabStop = true;
            this.rdoEspresso.Text = "Espresso ($2.49)";
            this.rdoEspresso.UseVisualStyleBackColor = true;
            // 
            // rdoRegular
            // 
            this.rdoRegular.AutoSize = true;
            this.rdoRegular.Location = new System.Drawing.Point(11, 22);
            this.rdoRegular.Name = "rdoRegular";
            this.rdoRegular.Size = new System.Drawing.Size(130, 20);
            this.rdoRegular.TabIndex = 0;
            this.rdoRegular.TabStop = true;
            this.rdoRegular.Text = "Regular ($1.99)";
            this.rdoRegular.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(719, 620);
            this.Controls.Add(this.grpCoffeeChoices);
            this.Controls.Add(this.grpTotal);
            this.Controls.Add(this.numQTY);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.listBox);
            this.Controls.Add(this.chkAddCoffee);
            this.Controls.Add(this.grpDonutChoices);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Emily\'s Donut Shop";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grpDonutChoices.ResumeLayout(false);
            this.grpDonutChoices.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numQTY)).EndInit();
            this.grpTotal.ResumeLayout(false);
            this.grpTotal.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numTax)).EndInit();
            this.grpCoffeeChoices.ResumeLayout(false);
            this.grpCoffeeChoices.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpDonutChoices;
        private System.Windows.Forms.RadioButton rdoChocAlmond;
        private System.Windows.Forms.RadioButton rdoBendera;
        private System.Windows.Forms.RadioButton rdoChocFrost;
        private System.Windows.Forms.RadioButton rdoBlackForest;
        private System.Windows.Forms.RadioButton rdoSugarRaised;
        private System.Windows.Forms.RadioButton rdoGlazed;
        private System.Windows.Forms.CheckBox chkAddCoffee;
        private System.Windows.Forms.ListView listBox;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.NumericUpDown numQTY;
        private System.Windows.Forms.GroupBox grpTotal;
        private System.Windows.Forms.TextBox txtChangeDue;
        private System.Windows.Forms.TextBox txtTendered;
        private System.Windows.Forms.TextBox txtTotalDue;
        private System.Windows.Forms.NumericUpDown numTax;
        private System.Windows.Forms.TextBox txtSubtotal;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grpCoffeeChoices;
        private System.Windows.Forms.ColumnHeader colItem;
        private System.Windows.Forms.ColumnHeader colQTY;
        private System.Windows.Forms.ColumnHeader colPrice;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.RadioButton rdoCappuccino;
        private System.Windows.Forms.RadioButton rdoEspresso;
        private System.Windows.Forms.RadioButton rdoRegular;
        private System.Windows.Forms.Label lblChocAlmond;
        private System.Windows.Forms.Label lblBendera;
        private System.Windows.Forms.Label lblChocFrost;
        private System.Windows.Forms.Label lblBlackForest;
        private System.Windows.Forms.Label lblSugarRaises;
        private System.Windows.Forms.Label lblGlazed;
    }
}

