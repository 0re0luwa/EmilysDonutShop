﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Emily_s_Donut_Shop
{
    public partial class Form1 : Form
    {
        decimal dcDonutPrice = 0m, dcSubtotal = 0m, dcCoffeePrice = 0m, changeDue = 0m;
       
        String donut;
        String coffee;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            getDonutPrice();
            getDonut();
            getCoffee();
            getCoffePrice();
            
            if (chkDonut())
            { 
                ListViewItem listItem = new ListViewItem(donut);
                listItem.SubItems.Add(numQTY.Value.ToString());
                listItem.SubItems.Add((numQTY.Value * dcDonutPrice).ToString());

                listBox.Items.Add(listItem);
                

                getSubtotal();

                numQTY.Value = 1;

            }
            if (chkCoffee()) 
            {
                ListViewItem lI = new ListViewItem(coffee);
                lI.SubItems.Add(numQTY.Value.ToString());
                lI.SubItems.Add((numQTY.Value * dcCoffeePrice).ToString());

                listBox.Items.Add(lI);

                getSubtotal();

                numQTY.Value = 1;

            }
        }

        private void chkAddCoffee_CheckedChanged(object sender, EventArgs e)
        {
            if (chkAddCoffee.Checked)
            {
                grpCoffeeChoices.Visible = true;
            }
            else if(!chkAddCoffee.Checked) {

                rdoRegular.Checked = false;
                rdoEspresso.Checked = false;
                rdoCappuccino.Checked = false;
                grpCoffeeChoices.Visible = false;
            }

        }

        private void getSubtotal()
        {
            foreach (ListViewItem li in listBox.Items)
            {
                dcSubtotal += decimal.Parse(li.SubItems[2].Text.Replace("$", " "));
            }

            txtSubtotal.Text = dcSubtotal.ToString("c");
            decimal total = dcSubtotal + (dcSubtotal * numTax.Value / 100);
            txtTotalDue.Text = total.ToString("c");

            changeDue = Convert.ToDecimal(txtTotalDue.Text.Replace("$", " ")) - Convert.ToDecimal(txtTendered.Text.Replace("$", " "));
            txtChangeDue.Text = "(" + changeDue.ToString("c") + ")";
        }

        private void numTax_ValueChanged(object sender, EventArgs e)
        {
            getSubtotal();
        }

        private void txtTendered_TextChanged(object sender, EventArgs e)
        {        
            if (!String.IsNullOrEmpty(txtTendered.Text)) 
            { 
                changeDue = Convert.ToDecimal(txtTotalDue.Text.Replace("$", " ")) - Convert.ToDecimal(txtTendered.Text.Replace("$", " "));
                txtChangeDue.Text = changeDue.ToString("c");
            }
        }

        private bool chkDonut()
        {
            if (rdoBendera.Checked)
            {
                return true;
            }
            else if (rdoBlackForest.Checked)
            {
                return true;
            }
            else if (rdoGlazed.Checked)
            {
                return true;
             
            }
            else if (rdoChocAlmond.Checked)
            {
                return true;
            }
            else if (rdoChocFrost.Checked)
            {
                return true;
            }
            else if (rdoSugarRaised.Checked)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void getDonut()
        {
            if (rdoBendera.Checked)
            {
                donut = lblBendera.Text;
            }
            else if (rdoBlackForest.Checked)
            {
                donut = lblBlackForest.Text;
            }
            else if (rdoGlazed.Checked)
            {
                donut = lblGlazed.Text;
            }
            else if (rdoChocAlmond.Checked)
            {
                donut = lblChocAlmond.Text;
            }
            else if (rdoChocFrost.Checked)
            {
                donut = lblChocFrost.Text;
            }
            else if (rdoSugarRaised.Checked)
            {
                donut = lblSugarRaises.Text;
            }
           
        }
        
        private bool chkCoffee()
        {
            if (rdoRegular.Checked)
            {
                return true;
            }
            else if (rdoEspresso.Checked)
            {
                return true;
            }
            else if (rdoCappuccino.Checked)
            {
                return true;
            }
            else
            {
                return false;
            }
            
        }

        private void getCoffee()
        {
            if (rdoRegular.Checked)
            {
                coffee = "Regular ($1.99)";
            }
            else if (rdoEspresso.Checked)
            {
                coffee = "Espresso ($2.49)";
            }
            else if (rdoCappuccino.Checked)
            {
                coffee = "Cappuccino ($3.49)";
            }
            
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            listBox.Items.Remove(listBox.SelectedItems[0]);

            getSubtotal();

        }

        public void getDonutPrice() 
        {
            if (rdoBendera.Checked)
            {
                dcDonutPrice = 2.55m;
            }
            else if (rdoBlackForest.Checked)
            {
                dcDonutPrice = 1.75m;
            }
            else if (rdoGlazed.Checked)
            {
                dcDonutPrice = 1.35m;
            }
            else if (rdoChocAlmond.Checked)
            {
                dcDonutPrice = 1.50m;
            }
            else if (rdoChocFrost.Checked)
            {
                dcDonutPrice = 1.90m;
            }
            else if (rdoSugarRaised.Checked)
            {
                dcDonutPrice = 1.45m;
            }
        }

        public void getCoffePrice()
        {
            if (rdoRegular.Checked)
            {
                dcCoffeePrice = 1.99m;
            }
            else if (rdoEspresso.Checked)
            {
                dcCoffeePrice = 2.49m;
            }
            else if (rdoCappuccino.Checked)
            {
                dcCoffeePrice = 3.49m;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            rdoGlazed.Focus();

            chkAddCoffee.Checked = true;
            chkAddCoffee.Checked = false;
        }

    }
}
